﻿using interfaceRecipeApplication;

namespace RecipeApp.Tests
{
    public class RecipeManagerTests
    {
        private RecipeManager _recipeManager;

        [SetUp]
        public void Setup()
        {
            _recipeManager = new RecipeManager();
        }

        [Test]
        public void AddRecipe_ShouldAddRecipeToList()
        {
            // Arrange
            var recipeName = "Pancakes";
            var ingredients = new List<Ingredient>
            {
                new Ingredient { Name = "Flour", Quantity = 200, Unit = "g", Calories = 400, OriginalQuantity = 200, OriginalCalories = 400 }
            };
            var steps = new List<Step>
            {
                new Step { Description = "Mix ingredients" }
            };

            // Act
            _recipeManager.AddRecipe(recipeName, ingredients, steps);

            // Assert
            Assert.AreEqual(1, _recipeManager.Recipes.Count);
            Assert.AreEqual(recipeName, _recipeManager.Recipes[0].Name);
        }

        [Test]
        public void ScaleIngredients_ShouldScaleIngredientsByFactor()
        {
            // Arrange
            var recipe = new Recipe
            {
                Name = "Pancakes",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Flour", Quantity = 200, Calories = 400, OriginalQuantity = 200, OriginalCalories = 400 }
                }
            };
            _recipeManager.Recipes.Add(recipe);

            // Act
            _recipeManager.ScaleIngredients(recipe, 2);

            // Assert
            Assert.AreEqual(400, recipe.Ingredients[0].Quantity);
            Assert.AreEqual(800, recipe.Ingredients[0].Calories);
        }

        [Test]
        public void ResetIngredients_ShouldResetIngredientsToOriginalValues()
        {
            // Arrange
            var recipe = new Recipe
            {
                Name = "Pancakes",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Flour", Quantity = 400, Calories = 800, OriginalQuantity = 200, OriginalCalories = 400 }
                }
            };
            _recipeManager.Recipes.Add(recipe);

            // Act
            _recipeManager.ResetIngredients(recipe);

            // Assert
            Assert.AreEqual(200, recipe.Ingredients[0].Quantity);
            Assert.AreEqual(400, recipe.Ingredients[0].Calories);
        }

        [Test]
        public void FilterRecipesByIngredient_ShouldReturnFilteredRecipes()
        {
            // Arrange
            var recipe1 = new Recipe
            {
                Name = "Pancakes",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Flour", Quantity = 200, Calories = 400 }
                }
            };
            var recipe2 = new Recipe
            {
                Name = "Omelette",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Egg", Quantity = 2, Calories = 150 }
                }
            };
            _recipeManager.Recipes.Add(recipe1);
            _recipeManager.Recipes.Add(recipe2);

            // Act
            var filteredRecipes = _recipeManager.FilterRecipesByIngredient("Egg");

            // Assert
            Assert.AreEqual(1, filteredRecipes.Count);
            Assert.AreEqual("Omelette", filteredRecipes[0].Name);
        }

        [Test]
        public void ClearRecipes_ShouldClearAllRecipes()
        {
            // Arrange
            _recipeManager.Recipes.Add(new Recipe { Name = "Pancakes" });

            // Act
            _recipeManager.ClearRecipes();

            // Assert
            Assert.AreEqual(0, _recipeManager.Recipes.Count);
        }
    }

    [TestFixture]
    public class IngredientTests
    {
        [Test]
        public void Ingredient_NameProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var name = "Sugar";

            // Act
            ingredient.Name = name;

            // Assert
            Assert.AreEqual(name, ingredient.Name);
        }

        [Test]
        public void Ingredient_QuantityProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var quantity = 1.5;

            // Act
            ingredient.Quantity = quantity;

            // Assert
            Assert.AreEqual(quantity, ingredient.Quantity);
        }

        [Test]
        public void Ingredient_UnitProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var unit = "cups";

            // Act
            ingredient.Unit = unit;

            // Assert
            Assert.AreEqual(unit, ingredient.Unit);
        }

        [Test]
        public void Ingredient_CaloriesProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var calories = 200;

            // Act
            ingredient.Calories = calories;

            // Assert
            Assert.AreEqual(calories, ingredient.Calories);
        }

        [Test]
        public void Ingredient_FoodGroupProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var foodGroup = "Dairy";

            // Act
            ingredient.FoodGroup = foodGroup;

            // Assert
            Assert.AreEqual(foodGroup, ingredient.FoodGroup);
        }

        [Test]
        public void Ingredient_OriginalQuantityProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var originalQuantity = 2.0;

            // Act
            ingredient.OriginalQuantity = originalQuantity;

            // Assert
            Assert.AreEqual(originalQuantity, ingredient.OriginalQuantity);
        }

        [Test]
        public void Ingredient_OriginalCaloriesProperty_GetSet()
        {
            // Arrange
            var ingredient = new Ingredient();
            var originalCalories = 150;

            // Act
            ingredient.OriginalCalories = originalCalories;

            // Assert
            Assert.AreEqual(originalCalories, ingredient.OriginalCalories);
        }
    }
    public class Ingredient
    {
        public string Name { get; set; }
        public double Calories { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }

    [TestFixture]
    public class RecipeTests
    {
        [Test]
        public void TotalCalories_NoIngredients_ReturnsZero()
        {
            // Arrange
            var recipe = new Recipe();

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(0, totalCalories);
        }

        [Test]
        public void TotalCalories_SingleIngredient_ReturnsIngredientCalories()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Name = "Sugar", Calories = 100 });

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(100, totalCalories);
        }

        [Test]
        public void TotalCalories_MultipleIngredients_ReturnsSumOfCalories()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Name = "Sugar", Calories = 100 });
            recipe.Ingredients.Add(new Ingredient { Name = "Flour", Calories = 200 });

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(300, totalCalories);
        }

        [Test]
        public void TotalCalories_IngredientsWithZeroCalories_ReturnsSumOfCalories()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Name = "Water", Calories = 0 });
            recipe.Ingredients.Add(new Ingredient { Name = "Salt", Calories = 0 });
            recipe.Ingredients.Add(new Ingredient { Name = "Sugar", Calories = 100 });

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(100, totalCalories);
        }
    }
}

using NUnit.Framework;

namespace interfaceRecipeApplication.Tests
{
    [TestFixture]
    public class StepTests
    {
        [Test]
        public void Step_DescriptionProperty_GetSet()
        {
            // Arrange
            var step = new Step();
            var description = "Mix all ingredients together.";

            // Act
            step.Description = description;

            // Assert
            Assert.AreEqual(description, step.Description);
        }

        [Test]
        public void Step_EmptyDescription_DefaultState()
        {
            // Arrange
            var step = new Step();

            // Act
            var description = step.Description;

            // Assert
            Assert.IsNull(description);
        }

        [Test]
        public void Step_DescriptionProperty_Null()
        {
            // Arrange
            var step = new Step();
            string description = null;

            // Act
            step.Description = description;

            // Assert
            Assert.IsNull(step.Description);
        }
    }

}
