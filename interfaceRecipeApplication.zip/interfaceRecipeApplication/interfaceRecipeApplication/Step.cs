﻿namespace interfaceRecipeApplication
{
    // Class to represent a step in the recipe.
    public class Step
    {
        public string Description { get; set; } // Description of the step.
    }
}
