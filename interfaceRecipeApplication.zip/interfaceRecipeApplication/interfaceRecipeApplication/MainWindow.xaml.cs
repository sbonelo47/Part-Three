﻿using System.Windows; // Namespace for WPF application functionalities.
using interfaceRecipeApplication; // Namespace for WPF control elements.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        // Static list to store all the recipes.
        public static List<Recipe> recipes = new List<Recipe>();

        // Constructor to initialize the MainWindow components.
        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for creating a new recipe.
        private void CreateRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Prompt("Enter the recipe name:"); // Prompt user for recipe name.
            if (string.IsNullOrWhiteSpace(recipeName)) return; // Check if the name is valid.

            Recipe recipe = new Recipe { Name = recipeName }; // Create a new recipe object.
            recipes.Add(recipe); // Add the new recipe to the list.

            AddIngredients(recipe); // Add ingredients to the recipe.
            AddSteps(recipe); // Add steps to the recipe.
        }

        // Method to add ingredients to a recipe.
        private void AddIngredients(Recipe recipe)
        {
            int numIngredients = int.Parse(Prompt("Enter the number of ingredients:")); // Prompt user for number of ingredients.
            for (int i = 0; i < numIngredients; i++) // Loop through each ingredient.
            {
                string name = Prompt($"Enter the name of ingredient {i + 1}:"); // Prompt for ingredient name.
                double quantity = double.Parse(Prompt($"Enter the quantity of {name}:")); // Prompt for ingredient quantity.
                string unit = Prompt($"Enter the unit of {name}:"); // Prompt for ingredient unit.
                double calories = double.Parse(Prompt($"Enter the calories of {name}:")); // Prompt for ingredient calories.
                string foodGroup = Prompt($"Enter the food group of {name}:"); // Prompt for ingredient food group.

                // Create a new ingredient object.
                Ingredient ingredient = new Ingredient
                {
                    Name = name,
                    Quantity = quantity,
                    Unit = unit,
                    Calories = calories,
                    FoodGroup = foodGroup,
                    OriginalQuantity = quantity,
                    OriginalCalories = calories
                };

                recipe.Ingredients.Add(ingredient); // Add the ingredient to the recipe.
            }
        }

        // Method to add steps to a recipe.
        private void AddSteps(Recipe recipe)
        {
            int numSteps = int.Parse(Prompt("Enter the number of steps:")); // Prompt user for number of steps.
            for (int i = 0; i < numSteps; i++) // Loop through each step.
            {
                string description = Prompt($"Enter the description of step {i + 1}:"); // Prompt for step description.
                recipe.Steps.Add(new Step { Description = description }); // Add the step to the recipe.
            }
        }

        // Event handler to display the list of recipes.
        private void DisplayRecipeListButton_Click(object sender, RoutedEventArgs e)
        {
            var sortedRecipes = recipes.OrderBy(r => r.Name).ToList(); // Sort recipes alphabetically by name.
            string recipeList = string.Join("\n", sortedRecipes.Select(r => r.Name)); // Create a string of recipe names.
            string selectedRecipeName = Prompt($"Recipes:\n{recipeList}\n\nEnter the name of the recipe to display:"); // Prompt user to select a recipe.

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(selectedRecipeName, StringComparison.OrdinalIgnoreCase)); // Find the selected recipe.
            if (selectedRecipe != null)
            {
                DisplayRecipe(selectedRecipe); // Display the selected recipe.
            }
        }

        // Method to display a recipe's details.
        private void DisplayRecipe(Recipe recipe)
        {
            string ingredients = string.Join("\n", recipe.Ingredients.Select(i => $"{i.Quantity} {i.Unit} {i.Name} ({i.Calories} calories)")); // Create a string of ingredients.
            string steps = string.Join("\n", recipe.Steps.Select((s, index) => $"{index + 1}. {s.Description}")); // Create a string of steps.
            string totalCalories = $"Total Calories: {recipe.TotalCalories()}"; // Calculate total calories.

            // Check if total calories exceed 300 and create a warning message if they do.
            string warning = recipe.TotalCalories() > 300 ? "Warning: Total calories exceed 300!" : string.Empty;

            // Combine all details into a single string.
            string recipeDetails = $"Recipe: {recipe.Name}\n\nIngredients:\n{ingredients}\n\nSteps:\n{steps}\n\n{totalCalories}\n{warning}";
            OutputTextBlock.Text = recipeDetails; // Display the recipe details.
        }

        // Event handler to scale the ingredients of a recipe.
        private void ScaleIngredientsButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Prompt("Enter the name of the recipe to scale:"); // Prompt user for recipe name.
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase)); // Find the recipe.
            if (recipe != null)
            {
                double scaleFactor = double.Parse(Prompt("Enter the scale factor (e.g., 0.5, 2, 3):")); // Prompt user for scale factor.
                ScaleIngredients(recipe, scaleFactor); // Scale the ingredients.
            }
        }

        // Method to scale the ingredients of a recipe.
        private void ScaleIngredients(Recipe recipe, double scaleFactor)
        {
            foreach (var ingredient in recipe.Ingredients) // Loop through each ingredient.
            {
                ingredient.Quantity *= scaleFactor; // Scale the quantity.
                ingredient.Calories *= scaleFactor; // Scale the calories.
            }
            OutputTextBlock.Text = $"Scaled ingredients for {recipe.Name} by a factor of {scaleFactor}."; // Display scaling confirmation.
        }

        // Event handler to reset the ingredients of a recipe to their original values.
        private void ResetIngredientsButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Prompt("Enter the name of the recipe to reset:"); // Prompt user for recipe name.
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase)); // Find the recipe.
            if (recipe != null)
            {
                foreach (var ingredient in recipe.Ingredients) // Loop through each ingredient.
                {
                    ingredient.Quantity = ingredient.OriginalQuantity; // Reset quantity to original value.
                    ingredient.Calories = ingredient.OriginalCalories; // Reset calories to original value.
                }
                OutputTextBlock.Text = $"Reset ingredients for {recipe.Name}."; // Display reset confirmation.
            }
        }

        // Event handler to filter recipes by an ingredient.
        private void FilterByIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = Prompt("Enter the name of the ingredient to filter recipes by:"); // Prompt user for ingredient name.
            var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))).OrderBy(r => r.Name).ToList(); // Find recipes containing the ingredient.

            if (filteredRecipes.Any()) // Check if any recipes were found.
            {
                string recipeList = string.Join("\n", filteredRecipes.Select(r => r.Name)); // Create a string of recipe names.
                OutputTextBlock.Text = $"Recipes containing {ingredientName}:\n{recipeList}"; // Display the filtered recipes.
            }
            else
            {
                OutputTextBlock.Text = $"No recipes found containing the ingredient: {ingredientName}"; // Display no recipes found message.
            }
        }

        // Event handler to clear all recipes.
        private void ClearRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear(); // Clear the recipes list.
            OutputTextBlock.Text = "All recipes have been cleared."; // Display clear confirmation.
        }

        // Event handler to exit the application.
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); // Shutdown the application.
        }

        // Helper method to display a prompt to the user and get input.
        private string Prompt(string message)
        {
            return Microsoft.VisualBasic.Interaction.InputBox(message, "Input", ""); // Display an input box with the message.
        }
    }
}
