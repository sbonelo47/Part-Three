﻿namespace interfaceRecipeApplication
{
    // Class to represent an ingredient.
    public class Ingredient
    {
        public string Name { get; set; } // Name of the ingredient.
        public double Quantity { get; set; } // Quantity of the ingredient.
        public string Unit { get; set; } // Unit of measurement for the quantity.
        public double Calories { get; set; } // Calories of the ingredient.
        public string FoodGroup { get; set; } // Food group of the ingredient.
        public double OriginalQuantity { get; set; } // Original quantity (for reset).
        public double OriginalCalories { get; set; } // Original calories (for reset).
    }
}
