﻿namespace interfaceRecipeApplication
{
    // Class to represent a recipe.
    public class Recipe
    {
        public string Name { get; set; } // Name of the recipe.
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>(); // List of ingredients.
        public List<Step> Steps { get; set; } = new List<Step>(); // List of steps.

        // Method to calculate the total calories of the recipe.
        public double TotalCalories()
        {
            return Ingredients.Sum(i => i.Calories); // Sum of calories of all ingredients.
        }
    }
}
